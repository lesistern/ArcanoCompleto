import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Footprints, Map, Compass, AlertTriangle } from 'lucide-react';

export function AdventureMovement() {
    return (
        <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100 text-base">
                            <Footprints className="h-4 w-4 text-blue-400" />
                            Táctico
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs text-dungeon-200">
                        <p className="mb-2"><strong>Para Combate.</strong></p>
                        <p>Se mide en pies (o casillas) por asalto (6 segundos).</p>
                        <div className="mt-2 bg-dungeon-950/30 p-2 rounded">
                            <p>Humano: 30 pies/asalto</p>
                            <p>Enano: 20 pies/asalto</p>
                            <p className="mt-1 text-[10px] text-dungeon-400">
                                Correr: x4 (Ligera/Sin armadura) | x3 (Pesada)
                            </p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100 text-base">
                            <Compass className="h-4 w-4 text-green-400" />
                            Local
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs text-dungeon-200">
                        <p className="mb-2"><strong>Para Mazmorras.</strong></p>
                        <p>Se mide en pies por minuto.</p>
                        <div className="mt-2 bg-dungeon-950/30 p-2 rounded">
                            <p>Caminar: 300 pies/min</p>
                            <p>Buscar trampas: Mitad de velocidad</p>
                        </div>
                    </CardContent>
                </Card>
                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100 text-base">
                            <Map className="h-4 w-4 text-amber-400" />
                            Por Tierra
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs text-dungeon-200">
                        <p className="mb-2"><strong>Para Viajes.</strong></p>
                        <p>Se mide en millas por hora o día.</p>
                        <div className="mt-2 bg-dungeon-950/30 p-2 rounded">
                            <p>Caminar: 3 millas/hora</p>
                            <p>Día (8h): 24 millas</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100">
                            <AlertTriangle className="h-5 w-5 text-orange-400" />
                            Terreno y Marcha Forzada
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 text-dungeon-200 text-sm">
                        <div>
                            <h4 className="font-bold text-dungeon-100 mb-1">Terreno Difícil</h4>
                            <p className="text-xs text-dungeon-300">
                                Bosques densos, pantanos, montañas.
                                <br />
                                <span className="text-orange-300">Coste: x2 (Te mueves a la mitad).</span>
                                <br />
                                Si no hay camino (campo a través), la velocidad se reduce aún más.
                            </p>
                        </div>
                        <div>
                            <h4 className="font-bold text-dungeon-100 mb-1">Marcha Forzada</h4>
                            <p className="text-xs text-dungeon-300">
                                Caminar más de 8 horas al día.
                            </p>
                            <ul className="list-disc list-inside mt-1 text-xs text-dungeon-400">
                                <li>Cada hora extra requiere prueba de <strong>Constitución (CD 10 + 2/hora)</strong>.</li>
                                <li>Fallo: <strong>1d6 daño no letal</strong> y quedas <strong>Fatigado</strong>.</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100">
                            <Footprints className="h-5 w-5 text-stone-400" />
                            Monturas y Vehículos
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm text-dungeon-200">
                        <table className="w-full text-xs text-left border-collapse">
                            <thead className="text-dungeon-200 border-b border-dungeon-800 bg-dungeon-950/20">
                                <tr>
                                    <th className="p-2">Transporte</th>
                                    <th className="p-2">Por Hora</th>
                                    <th className="p-2">Por Día</th>
                                </tr>
                            </thead>
                            <tbody className="text-dungeon-300 divide-y divide-dungeon-800/30">
                                <tr><td className="p-2">Caballo Ligero</td><td>6 millas</td><td>48 millas</td></tr>
                                <tr><td className="p-2">Caballo Pesado</td><td>5 millas</td><td>40 millas</td></tr>
                                <tr><td className="p-2">Pony / Mula</td><td>3 millas</td><td>24 millas</td></tr>
                                <tr><td className="p-2">Carreta</td><td>2 millas</td><td>16 millas</td></tr>
                                <tr><td className="p-2 text-blue-300">Barco de Vela</td><td className="text-blue-300">2 millas</td><td className="text-blue-300">48 millas (24h)</td></tr>
                            </tbody>
                        </table>
                        <p className="text-[10px] text-dungeon-400 mt-2">
                            * Los caballos también se cansan y sufren daño letal si se les fuerza a marchar.
                        </p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100">
                            <Footprints className="h-5 w-5 text-cyan-400" />
                            Movimiento Especial
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 text-dungeon-200 text-sm">
                        <div>
                            <h4 className="font-bold text-dungeon-100 mb-1">Vuelo y Maniobrabilidad</h4>
                            <p className="text-xs text-dungeon-300 mb-2">
                                Volar no es tan fácil como caminar. Cada criatura tiene una clase de maniobrabilidad.
                            </p>
                            <div className="bg-dungeon-950/30 p-2 rounded grid grid-cols-2 gap-2 text-xs">
                                <div>
                                    <span className="text-cyan-300 font-bold">Perfecta/Buena:</span>
                                    <br />Puede flotar y girar fácil.
                                </div>
                                <div>
                                    <span className="text-red-300 font-bold">Media/Pobre:</span>
                                    <br />Debe moverse para no caer. Giros amplios.
                                </div>
                            </div>
                        </div>
                        <div>
                            <h4 className="font-bold text-dungeon-100 mb-1">Persecuciones</h4>
                            <ul className="list-disc list-inside text-xs text-dungeon-300 space-y-1">
                                <li>
                                    <strong>Corta (Rondas):</strong> Chequeos opuestos de <span className="text-green-400">Destreza</span>.
                                </li>
                                <li>
                                    <strong>Larga (Horas):</strong> Chequeos opuestos de <span className="text-orange-400">Constitución</span>.
                                </li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-dungeon-700 bg-dungeon-900/50">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-dungeon-100">
                            <Map className="h-5 w-5 text-purple-400" />
                            Orden de Marcha
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm text-dungeon-200">
                        <p className="mb-2">
                            Decidir quién va delante y quién detrás es vital para sobrevivir a una emboscada.
                        </p>
                        <div className="grid md:grid-cols-3 gap-4 text-xs text-center">
                            <div className="bg-dungeon-950/30 p-2 rounded">
                                <strong className="text-red-400 block mb-1">Vanguardia</strong>
                                <p className="text-dungeon-300">Guerreros, Paladines, Bárbaros.</p>
                                <p className="text-[10px] text-dungeon-400">Los más duros para recibir el primer golpe.</p>
                            </div>
                            <div className="bg-dungeon-950/30 p-2 rounded">
                                <strong className="text-blue-400 block mb-1">Centro</strong>
                                <p className="text-dungeon-300">Magos, Hechiceros, Bardos.</p>
                                <p className="text-[10px] text-dungeon-400">Protegidos por ambos lados.</p>
                            </div>
                            <div className="bg-dungeon-950/30 p-2 rounded">
                                <strong className="text-green-400 block mb-1">Retaguardia</strong>
                                <p className="text-dungeon-300">Clérigos, Druidas, Pícaros.</p>
                                <p className="text-[10px] text-dungeon-400">Vigilan la espalda y protegen a los débiles.</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
