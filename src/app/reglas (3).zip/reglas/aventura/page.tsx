"use client";

import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/Button";
import {
    Weight,
    Map,
    Lightbulb,
    Coins
} from 'lucide-react';
import { CarryingCapacity } from './CarryingCapacity';
import { AdventureMovement } from './AdventureMovement';
import { Exploration } from './Exploration';
import { Treasure } from './Treasure';

type Tab = 'carga' | 'movimiento' | 'exploracion' | 'tesoro';

export default function AdventurePage() {
    const [activeTab, setActiveTab] = useState<Tab>('carga');
    const contentRef = useRef<HTMLDivElement>(null);

    const handleTabChange = (tabId: Tab) => {
        setActiveTab(tabId);
        // Small timeout to ensure state update and render cycle have started
        setTimeout(() => {
            if (contentRef.current) {
                const y = contentRef.current.getBoundingClientRect().top + window.scrollY - 180; // Adjust offset for header + tabs
                window.scrollTo({ top: y, behavior: 'smooth' });
            }
        }, 0);
    };

    const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
        { id: 'carga', label: 'Carga y Equipo', icon: Weight },
        { id: 'movimiento', label: 'Movimiento y Viajes', icon: Map },
        { id: 'exploracion', label: 'Exploración', icon: Lightbulb },
        { id: 'tesoro', label: 'Tesoros', icon: Coins },
    ];

    return (
        <div className="container mx-auto py-8 space-y-8">
            <div className="flex flex-col space-y-4">
                <h1 className="text-4xl font-bold text-dungeon-100 text-center font-serif">
                    Aventura
                </h1>
                <p className="text-xl text-dungeon-300 text-center max-w-3xl mx-auto">
                    El mundo es vasto y peligroso. Aquí aprenderás a sobrevivir en el camino, gestionar tu equipo y reclamar tus recompensas.
                </p>
            </div>

            {/* Navigation Tabs */}
            <div className="flex flex-wrap justify-center gap-2 sticky top-20 z-40 bg-dungeon-950/90 p-4 rounded-xl backdrop-blur-sm border border-dungeon-800 shadow-xl">
                {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                        <Button
                            key={tab.id}
                            variant={activeTab === tab.id ? "default" : "outline"}
                            onClick={() => handleTabChange(tab.id)}
                            className={`flex items-center gap-2 transition-all duration-300 ${activeTab === tab.id
                                ? 'bg-amber-900/80 hover:bg-amber-800 text-amber-100 border-amber-700 shadow-lg shadow-amber-900/20 scale-105'
                                : 'text-dungeon-300 border-dungeon-700 hover:bg-dungeon-800 hover:text-dungeon-100'
                                }`}
                        >
                            <Icon className="h-4 w-4" />
                            <span className="hidden md:inline">{tab.label}</span>
                        </Button>
                    );
                })}
            </div>

            {/* Content Area */}
            <div ref={contentRef} className="min-h-[500px] animate-in fade-in slide-in-from-bottom-4 duration-500 scroll-mt-40">
                {activeTab === 'carga' && <CarryingCapacity />}
                {activeTab === 'movimiento' && <AdventureMovement />}
                {activeTab === 'exploracion' && <Exploration />}
                {activeTab === 'tesoro' && <Treasure />}
            </div>
        </div>
    );
}
