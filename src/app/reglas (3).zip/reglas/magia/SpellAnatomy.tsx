import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Mic, Hand, Package, Clock, Ruler, ShieldCheck, ArrowRight, Book } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface SpellAnatomyProps {
    onNextTab?: () => void;
}

export function SpellAnatomy({ onNextTab }: SpellAnatomyProps) {
    const scrollToId = (id: string) => {
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-purple-900/20 border border-purple-500/30 p-4 rounded-lg flex gap-4 items-start">
                <Book className="h-6 w-6 text-purple-400 flex-shrink-0 mt-1" />
                <div>
                    <h3 className="font-bold text-purple-300 text-lg">Leyendo el Manual</h3>
                    <p className="text-dungeon-200 text-sm">
                        Cada conjuro tiene una "ficha técnica". Antes de lanzarlo, revisa estos 4 datos clave para no equivocarte.
                    </p>
                </div>
            </div>

            {/* Componentes */}
            <Card id="components" className="border-dungeon-700 bg-dungeon-900/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-dungeon-100">
                        <Package className="h-5 w-5 text-amber-400" />
                        1. ¿Qué necesito? (Componentes)
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-dungeon-200 text-sm">
                    <p>
                        Mira las letras al lado de "Componentes". Te dicen qué debes hacer físicamente.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-dungeon-950/30 p-3 rounded border border-dungeon-800">
                            <div className="flex items-center gap-2 mb-1">
                                <Mic className="h-4 w-4 text-amber-400" />
                                <strong className="text-amber-200">V (Verbal)</strong>
                            </div>
                            <p className="text-xs text-dungeon-300">Tienes que hablar fuerte. <br /><span className="text-dungeon-500 italic">No funciona si estás amordazado o en silencio mágico.</span></p>
                        </div>
                        <div className="bg-dungeon-950/30 p-3 rounded border border-dungeon-800">
                            <div className="flex items-center gap-2 mb-1">
                                <Hand className="h-4 w-4 text-amber-400" />
                                <strong className="text-amber-200">S (Somático)</strong>
                            </div>
                            <p className="text-xs text-dungeon-300">Tienes que mover las manos. <br /><span className="text-dungeon-500 italic">No funciona si estás atado.</span></p>
                        </div>
                        <div className="bg-dungeon-950/30 p-3 rounded border border-dungeon-800">
                            <div className="flex items-center gap-2 mb-1">
                                <Package className="h-4 w-4 text-amber-400" />
                                <strong className="text-amber-200">M (Material)</strong>
                            </div>
                            <p className="text-xs text-dungeon-300">Necesitas un ingrediente (pata de araña, arena, etc). <br /><span className="text-dungeon-500 italic">Suele venir en tu bolsa de componentes.</span></p>
                        </div>
                    </div>
                    <div className="flex justify-end pt-2">
                        <Button variant="ghost" size="sm" onClick={() => scrollToId('time-range')} className="text-amber-300 hover:text-amber-200">
                            Siguiente: Tiempo <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Tiempo */}
            <Card id="time-range" className="border-dungeon-700 bg-dungeon-900/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-dungeon-100">
                        <Clock className="h-5 w-5 text-cyan-400" />
                        2. ¿Cuánto tardo? (Tiempo de Lanzamiento)
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-dungeon-200 text-sm">
                    <div className="space-y-2">
                        <div className="flex justify-between items-center border-b border-dungeon-800 pb-2">
                            <span className="text-dungeon-100 font-bold">1 Acción Estándar</span>
                            <span className="text-cyan-200 text-right text-xs max-w-[60%]">Lo normal. Lanzas y todavía te puedes mover.</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-dungeon-800 pb-2">
                            <span className="text-dungeon-100 font-bold">1 Asalto Completo</span>
                            <span className="text-cyan-200 text-right text-xs max-w-[60%]">Muy lento. Empiezas ahora y termina justo antes de tu próximo turno.</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-dungeon-800 pb-2">
                            <span className="text-dungeon-100 font-bold">Acción Rápida</span>
                            <span className="text-cyan-200 text-right text-xs max-w-[60%]">¡Instantáneo! Lo lanzas y aún puedes atacar o lanzar otro conjuro normal.</span>
                        </div>
                    </div>
                    <div className="flex justify-end pt-2">
                        <Button variant="ghost" size="sm" onClick={() => scrollToId('area-target')} className="text-cyan-300 hover:text-cyan-200">
                            Siguiente: Distancia <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Distancia */}
            <Card id="area-target" className="border-dungeon-700 bg-dungeon-900/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-dungeon-100">
                        <Ruler className="h-5 w-5 text-red-400" />
                        3. ¿Llego? (Alcance y Área)
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-dungeon-200 text-sm">
                    <p>
                        No puedes lanzar una Bola de Fuego si no llegas.
                    </p>
                    <ul className="grid grid-cols-2 gap-2 text-xs text-dungeon-300">
                        <li className="bg-dungeon-950/30 p-2 rounded"><strong>Personal:</strong> Solo para ti.</li>
                        <li className="bg-dungeon-950/30 p-2 rounded"><strong>Toque:</strong> Tienes que tocar al enemigo (¡peligroso!).</li>
                        <li className="bg-dungeon-950/30 p-2 rounded"><strong>Cercano:</strong> ~7.5m (Pistola).</li>
                        <li className="bg-dungeon-950/30 p-2 rounded"><strong>Medio:</strong> ~30m (Rifle).</li>
                        <li className="bg-dungeon-950/30 p-2 rounded"><strong>Largo:</strong> ~120m (Francotirador).</li>
                    </ul>
                    <div className="mt-4 border-t border-dungeon-800 pt-2">
                        <strong className="text-red-300 text-xs">Formas de Área:</strong>
                        <p className="text-xs text-dungeon-400 mt-1">
                            A veces no apuntas a uno, sino a una zona. <strong>Cono</strong> (lanzallamas), <strong>Explosión</strong> (granada), <strong>Línea</strong> (rayo láser).
                        </p>
                    </div>
                    <div className="flex justify-end pt-2">
                        <Button variant="ghost" size="sm" onClick={() => scrollToId('saving-throws')} className="text-red-300 hover:text-red-200">
                            Siguiente: Duración <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Duración */}
            <Card id="saving-throws" className="border-dungeon-700 bg-dungeon-900/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-dungeon-100">
                        <ShieldCheck className="h-5 w-5 text-green-400" />
                        4. ¿Cuánto dura?
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-dungeon-200 text-sm">
                    <ul className="list-disc list-inside space-y-2 text-xs text-dungeon-300">
                        <li><strong>Instantáneo:</strong> Pasa y se acaba (como una explosión). El daño se queda, pero la magia se va.</li>
                        <li><strong>Rounds/Minutos/Horas:</strong> El efecto persiste un tiempo.</li>
                        <li>
                            <strong className="text-green-400">Concentración:</strong> ¡Ojo! El conjuro dura mientras te concentres. Si lanzas otro conjuro o te pegan fuerte, se puede acabar antes.
                        </li>
                    </ul>
                    {onNextTab && (
                        <div className="flex justify-end pt-4 border-t border-dungeon-800 mt-4">
                            <Button onClick={onNextTab} className="bg-dungeon-800 hover:bg-dungeon-700 text-dungeon-100">
                                Siguiente: Tipos de Magia <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
