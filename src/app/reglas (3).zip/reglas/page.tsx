import Link from 'next/link';
import { createStaticClient } from '@/lib/supabase/server';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Shield, Brain, Dices, BookOpen, Scroll, Users, Swords, Target, Zap, Backpack, Map, Wand2, Book, Crown, UserPlus } from 'lucide-react';
import { getAbilityIconById, getAbilityColorById } from '@/lib/utils/icons';
import { getDiceIcon } from '@/lib/utils/diceIcons';
import { RuleCard } from '@/components/reglas/RuleCard';
import { ExpandableRuleSection } from '@/components/reglas/ExpandableRuleSection';

// Force static generation and cache for 1 hour
export const revalidate = 3600;
export const dynamic = 'force-static';
export const dynamicParams = false;

export const metadata = {
    title: 'Reglas - Compendio Arcano',
    description: 'Guía completa de reglas del sistema d20: reglas básicas, creación de personaje, características y más.',
};

export default async function RulesPage() {
    const supabase = await createStaticClient();

    const [
        { data: dice },
        { data: abilityScores },
        { data: savingThrows },
        { data: rulesContent },
    ] = await Promise.all([
        supabase.from('dice').select('id, sides, description, slug').order('sides'),
        supabase.from('ability_scores').select('id, name, abbreviation, description, slug').order('id'),
        supabase.from('saving_throws').select('id, name, description, slug, ability_score_id'),
        supabase.from('rules_content').select('slug, title, description, category').order('display_order'),
    ]);

    // Pre-sorted data
    const abilityOrder = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
    const sortedAbilities = abilityScores?.slice().sort(
        (a, b) => abilityOrder.indexOf(a.id) - abilityOrder.indexOf(b.id)
    );

    return (
        <div className="container mx-auto px-4 py-16 max-w-6xl">
            <div className="mb-12 space-y-3 border-l-4 border-gold-500 pl-6">
                <h1 className="font-heading text-4xl md:text-5xl font-bold text-dungeon-100">
                    Reglas del sistema
                </h1>
                <p className="text-lg text-dungeon-300">
                    Guía completa del sistema d20: mecánicas básicas, creación de personajes y características.
                </p>
            </div>

            <div className="mt-8 mb-12">
                <ExpandableRuleSection
                    title="Resumen Rápido: Fundamentos del Juego"
                    summary="Todo lo que necesitas saber para empezar a jugar D&D 3.5 en menos de 5 minutos: desde la mecánica del d20 hasta cómo crear tu primer personaje."
                    icon={<Scroll className="h-6 w-6 text-gold-500" />}
                >
                    <div className="space-y-6">
                        <div>
                            <h3 className="text-lg font-bold text-gold-400 mb-2">La Regla Básica</h3>
                            <p>
                                La mecánica central de D&D es simple: cuando intentas algo con posibilidad de fallo, tiras un dado de 20 caras (<strong>d20</strong>).
                            </p>
                            <ul className="list-disc pl-5 mt-2 space-y-1 text-dungeon-200">
                                <li><strong>Tira un d20.</strong></li>
                                <li><strong>Suma los modificadores</strong> (por tus características, habilidades o equipo).</li>
                                <li><strong>Compara con el Objetivo</strong> (Clase de Dificultad o Clase de Armadura).</li>
                            </ul>
                            <p className="mt-2">Si igualas o superas el número, ¡tienes éxito!</p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6">
                            <div>
                                <h3 className="text-lg font-bold text-gold-400 mb-2">Qué Necesitas</h3>
                                <ul className="list-disc pl-5 space-y-1 text-dungeon-200">
                                    <li><strong>Hoja de Personaje:</strong> Digital o impresa.</li>
                                    <li><strong>Dados:</strong> Juego completo (d4, d6, d8, d10, d12, d20).</li>
                                    <li><strong>Tablero y Minis:</strong> O simplemente imaginación ("Teatro de la Mente").</li>
                                    <li><strong>Lápiz y Papel:</strong> Para notas y mapas.</li>
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-gold-400 mb-2">Tipos de Acciones</h3>
                                <ul className="list-disc pl-5 space-y-1 text-dungeon-200">
                                    <li><strong>Pruebas de Habilidad:</strong> Usar una destreza entrenada (ej. Trepar, Diplomacia).</li>
                                    <li><strong>Pruebas de Característica:</strong> Fuerza bruta, agilidad natural, etc.</li>
                                    <li><strong>Tiradas de Ataque:</strong> Intentar golpear a un enemigo en combate.</li>
                                </ul>
                            </div>
                        </div>

                        <div>
                            <h3 className="text-lg font-bold text-gold-400 mb-2">El Combate</h3>
                            <p>
                                Se divide en <strong>asaltos</strong> de 6 segundos. El orden se decide por <strong>Iniciativa</strong> (d20 + Des).
                                En tu turno puedes moverte y realizar una acción estándar (atacar, lanzar conjuro) o hacer una acción de asalto completo.
                            </p>
                        </div>

                        <div className="bg-dungeon-900/50 p-4 rounded-lg border border-dungeon-700">
                            <h3 className="text-lg font-bold text-gold-400 mb-2">Creación de Personaje en 6 Pasos</h3>
                            <ol className="list-decimal pl-5 space-y-2 text-dungeon-200">
                                <li><strong>Características:</strong> Tira 4d6 (descarta el bajo) 6 veces. Asigna a Fue, Des, Con, Int, Sab, Car.</li>
                                <li><strong>Raza y Clase:</strong> Elige tu combinación (ej. Enano Guerrero, Elfo Mago). Aplica ajustes raciales.</li>
                                <li><strong>Habilidades y Dotes:</strong> Gasta puntos de habilidad según tu Int y clase. Elige una dote (2 si eres humano o guerrero).</li>
                                <li><strong>Equipo:</strong> Compra armas y armadura con tu oro inicial o usa el paquete de clase.</li>
                                <li><strong>Datos de Combate:</strong> Calcula CA, Ataque, Salvaciones e Iniciativa.</li>
                                <li><strong>Detalles:</strong> Nombre, alineamiento, dios, edad y apariencia.</li>
                            </ol>
                        </div>
                    </div>
                </ExpandableRuleSection>
            </div>

            <div className="space-y-16">
                {/* Guías Principales */}
                <section id="guias-principales">
                    <div className="flex items-center gap-3 mb-6">
                        <BookOpen className="h-8 w-8 text-gold-500" />
                        <h2 className="text-2xl font-bold text-dungeon-100">Guías principales</h2>
                    </div>
                    <div className="grid gap-6 md:grid-cols-3">
                        {/* 1. Reglas básicas */}
                        <Link
                            href="/reglas/reglas-basicas"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Dices className="h-12 w-12 text-gold-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Reglas básicas
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Aprende la mecánica central del d20, tipos de tiradas, combate y conceptos fundamentales del juego.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 2. Creación de personaje */}
                        <Link
                            href="/reglas/creacion-personaje"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <UserPlus className="h-12 w-12 text-blue-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Creación de personaje
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Guía paso a paso para crear tu aventurero: características, raza, clase, habilidades y equipo.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 3. Características */}
                        <Link
                            href="/reglas/caracteristicas"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Brain className="h-12 w-12 text-purple-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Características
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Detalles completos sobre las seis características: Fuerza, Destreza, Constitución, Inteligencia, Sabiduría y Carisma.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 4. Razas */}
                        <Link
                            href="/reglas/razas"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Users className="h-12 w-12 text-green-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Razas
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Cómo elegir una raza, cualidades raciales, idiomas y ajustes de característica.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 5. Clases */}
                        <Link
                            href="/reglas/clases"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Crown className="h-12 w-12 text-red-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Clases
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Resumen de clases, bonificadores, beneficios por nivel y progresión de personaje.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 6. Habilidades */}
                        <Link
                            href="/reglas/habilidades"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Target className="h-12 w-12 text-orange-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Habilidades
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Reglas sobre obtención de rangos, pruebas de habilidad, sinergias y usos especiales.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 7. Dotes */}
                        <Link
                            href="/reglas/dotes"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Zap className="h-12 w-12 text-yellow-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Dotes
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Capacidades especiales, desde combate y magia hasta creación de objetos y herencias.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 8. Descripción */}
                        <Link
                            href="/reglas/descripcion"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Scroll className="h-12 w-12 text-gold-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Descripción
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Detalles que dan vida a tu personaje: alineamiento, religión, apariencia, personalidad y trasfondo.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 9. Equipamiento */}
                        <Link
                            href="/reglas/equipamiento"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Backpack className="h-12 w-12 text-amber-500" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Equipamiento
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Armas, armaduras, bienes y servicios para equipar a tu personaje para la aventura.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 10. Combate */}
                        <Link
                            href="/reglas/combate"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Swords className="h-12 w-12 text-red-500" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Combate
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Iniciativa, acciones, ataque, daño, movimiento táctico y maniobras especiales.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 11. Aventura */}
                        <Link
                            href="/reglas/aventura"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Map className="h-12 w-12 text-emerald-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Aventura
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Exploración, movimiento, luz, carga, trampas y peligros del entorno.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 12. Magia */}
                        <Link
                            href="/reglas/magia"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Wand2 className="h-12 w-12 text-violet-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Magia
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Lanzamiento de conjuros, escuelas de magia, componentes y concentración.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>

                        {/* 13. Conjuros */}
                        <Link
                            href="/reglas/conjuros"
                            className="block transition-transform hover:scale-[1.02]"
                        >
                            <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                <CardHeader className="pb-3">
                                    <div className="flex justify-center mb-3">
                                        <Book className="h-12 w-12 text-indigo-400" />
                                    </div>
                                    <CardTitle className="text-xl text-center text-dungeon-100">
                                        Conjuros
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-dungeon-300 text-center">
                                        Listas de conjuros por clase y descripciones detalladas de cada hechizo.
                                    </p>
                                    <div className="mt-4 text-center">
                                        <span className="text-xs text-gold-500 font-medium">
                                            Leer guía completa →
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    </div>
                </section>

                {/* Puntuaciones de Característica */}
                <section id="caracteristicas">
                    <div className="flex items-center gap-3 mb-6">
                        <Brain className="h-8 w-8 text-gold-500" />
                        <h2 className="text-2xl font-bold text-dungeon-100">Puntuaciones de característica</h2>
                    </div>
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                        {sortedAbilities?.map((ability) => (
                            <RuleCard
                                key={ability.id}
                                href={`/reglas/puntuaciones-caracteristica/${ability.slug}`}
                                icon={getAbilityIconById(ability.id)}
                                iconColor={getAbilityColorById(ability.id)}
                                title={ability.name}
                                abbreviation={ability.abbreviation}
                                description={ability.description}
                            />
                        ))}
                    </div>
                </section>

                {/* Salvaciones */}
                <section id="salvaciones">
                    <div className="flex items-center gap-3 mb-6">
                        <Shield className="h-8 w-8 text-gold-500" />
                        <h2 className="text-2xl font-bold text-dungeon-100">Tiradas de salvación</h2>
                    </div>
                    <div className="grid gap-6 md:grid-cols-3">
                        {savingThrows?.map((save) => {
                            const ability = sortedAbilities?.find(a => a.id === save.ability_score_id);
                            const AbilityIcon = ability ? getAbilityIconById(ability.id) : Brain;
                            const colorClass = ability ? getAbilityColorById(ability.id) : 'text-dungeon-400';

                            return (
                                <Link
                                    key={save.id}
                                    href={`/reglas/salvaciones/${save.slug}`}
                                    className="block transition-transform hover:scale-[1.02]"
                                >
                                    <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                        <CardHeader className="pb-2">
                                            <CardTitle className="flex items-center gap-2 text-lg text-dungeon-100">
                                                {save.name}
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-3">
                                            <p className="text-sm text-dungeon-200 line-clamp-3">{save.description}</p>
                                            <div className="flex items-center gap-2 text-xs text-dungeon-400 bg-dungeon-900/50 p-2 rounded">
                                                <AbilityIcon className={`h-4 w-4 ${colorClass}`} />
                                                <span>Basada en {ability?.name || 'Característica'}</span>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </Link>
                            );
                        })}
                    </div>
                </section>

                {/* Dados */}
                <section id="dados">
                    <div className="flex items-center gap-3 mb-6">
                        <Dices className="h-8 w-8 text-gold-500" />
                        <h2 className="text-2xl font-bold text-dungeon-100">Dados</h2>
                    </div>
                    <div className="grid gap-4 grid-cols-2 md:grid-cols-4 lg:grid-cols-7">
                        {dice?.map((d) => {
                            const DiceIcon = getDiceIcon(d.sides);
                            return (
                                <Link
                                    key={d.id}
                                    href={`/reglas/dados/${d.slug}`}
                                    className="block transition-transform hover:scale-[1.02]"
                                >
                                    <Card className="card text-center h-full hover:border-gold-500/50 transition-colors">
                                        <CardHeader className="pb-2 pt-4">
                                            <div className="flex justify-center mb-2">
                                                <DiceIcon className="h-8 w-8 text-gold-400" />
                                            </div>
                                            <CardTitle className="text-lg font-mono text-gold-400">
                                                {d.id}
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="pb-4">
                                            <p className="text-xs text-dungeon-300 line-clamp-3" title={d.description}>
                                                {d.description}
                                            </p>
                                        </CardContent>
                                    </Card>
                                </Link>
                            );
                        })}
                    </div>
                </section>

                {/* Reglas Adicionales */}
                {
                    rulesContent && rulesContent.length > 0 && (
                        <section id="reglas-adicionales">
                            <div className="flex items-center gap-3 mb-6">
                                <BookOpen className="h-8 w-8 text-gold-500" />
                                <h2 className="text-2xl font-bold text-dungeon-100">Reglas adicionales</h2>
                            </div>
                            <div className="grid gap-6 md:grid-cols-2">
                                {rulesContent.map((rule) => (
                                    <Link
                                        key={rule.slug}
                                        href={`/reglas/contenido/${rule.slug}`}
                                        className="block transition-transform hover:scale-[1.02]"
                                    >
                                        <Card className="card h-full hover:border-gold-500/50 transition-colors">
                                            <CardHeader className="pb-2">
                                                <CardTitle className="flex items-center gap-2 text-lg text-dungeon-100">
                                                    {rule.title}
                                                </CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-3">
                                                <p className="text-sm text-dungeon-200 line-clamp-3">{rule.description}</p>
                                            </CardContent>
                                        </Card>
                                    </Link>
                                ))}
                            </div>
                        </section>
                    )
                }

            </div >
        </div >
    );
}
