import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { ArrowLeft, Dices, Target, Swords, Heart, Shield, Zap, CheckCircle, XCircle, Calculator, Divide, BookOpen, ChevronDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';

export const metadata = {
    title: 'Reglas Básicas - Compendio Arcano',
    description: 'Guía completa de las reglas básicas del sistema d20: mecánica central, tipos de tiradas y combate.',
};

export default function ReglasBasicasPage() {
    return (
        <div className="container mx-auto px-4 py-16 max-w-5xl">
            {/* Back Button */}
            <div className="mb-8">
                <Link href="/reglas">
                    <Button variant="outline">
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Volver a reglas
                    </Button>
                </Link>
            </div>

            {/* Header */}
            <div className="border-l-4 border-gold-500 pl-6 mb-12">
                <div className="flex items-center gap-3 mb-3">
                    <Dices className="h-8 w-8 text-gold-400" />
                    <h1 className="font-heading text-4xl md:text-5xl font-bold text-dungeon-100">
                        Reglas básicas del sistema d20
                    </h1>
                </div>
                <p className="text-lg text-dungeon-300">
                    Todo lo que necesitas saber para empezar a jugar.
                </p>
            </div>

            {/* Content */}
            <div className="space-y-8">
                {/* Glosario de Términos */}
                <Card className="card border-dungeon-500/30">
                    <details className="group">
                        <summary className="flex items-center justify-between p-6 cursor-pointer list-none bg-gradient-to-r from-dungeon-800/50 to-transparent rounded-t-lg hover:bg-dungeon-800/70 transition-colors">
                            <div className="flex items-center gap-3 text-2xl font-bold text-dungeon-100">
                                <BookOpen className="h-6 w-6 text-dungeon-200" />
                                Glosario de Términos Comunes
                            </div>
                            <ChevronDown className="h-6 w-6 text-dungeon-400 transition-transform group-open:rotate-180" />
                        </summary>
                        <CardContent className="p-6 border-t border-dungeon-700">
                            <div className="grid md:grid-cols-2 gap-x-8 gap-y-4">
                                {[
                                    { term: 'DG (Dados de Golpe)', def: 'Determinan tus Puntos de Golpe (PG) y reflejan tu nivel y resistencia.' },
                                    { term: 'BAB (Ataque Base)', def: 'Tu bonificador base al ataque, derivado de tu clase y nivel.' },
                                    { term: 'CA (Clase de Armadura)', def: 'La dificultad para ser golpeado en combate. 10 + bonificadores.' },
                                    { term: 'CD (Clase de Dificultad)', def: 'El número objetivo que debes igualar o superar en una tirada para tener éxito.' },
                                    { term: 'PG (Puntos de Golpe)', def: 'La cantidad de daño que puedes soportar antes de caer inconsciente o morir.' },
                                    { term: 'PJE (Personaje Jugador)', def: 'Un personaje controlado por un jugador.' },
                                    { term: 'PNJ (Personaje No Jugador)', def: 'Un personaje controlado por el Dungeon Master.' },
                                    { term: 'DM (Dungeon Master)', def: 'El narrador y árbitro del juego.' },
                                    { term: 'Iniciativa', def: 'Determina el orden de actuación en combate.' },
                                    { term: 'Asalto (Round)', def: 'Un periodo de tiempo de aproximadamente 6 segundos en el juego.' },
                                ].map((item) => (
                                    <div key={item.term} className="text-sm">
                                        <span className="font-bold text-gold-400 block mb-1">{item.term}</span>
                                        <span className="text-dungeon-300">{item.def}</span>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </details>
                </Card>
                {/* La mecánica central */}
                <Card className="card border-gold-500/30">
                    <CardHeader className="bg-gradient-to-r from-gold-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Target className="h-6 w-6 text-gold-400" />
                            La mecánica central
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                        <p className="text-lg text-dungeon-200 mb-6">
                            El sistema utiliza un <span className="text-gold-400 font-bold">dado de veinte caras (d20)</span> como base para resolver todas las acciones importantes.
                        </p>

                        <div className="bg-gradient-to-r from-gold-900/20 to-purple-900/20 border-2 border-gold-500/50 rounded-lg p-6 mb-6">
                            <h3 className="text-xl font-bold text-gold-300 mb-4">Fórmula básica:</h3>
                            <div className="flex items-center gap-3 flex-wrap justify-center text-lg font-mono">
                                <span className="bg-dungeon-800 px-4 py-2 rounded border border-gold-500/30">1d20</span>
                                <span className="text-gold-400 text-2xl">+</span>
                                <span className="bg-dungeon-800 px-4 py-2 rounded border border-blue-500/30">Modificadores</span>
                                <span className="text-gold-400 text-2xl">≥</span>
                                <span className="bg-dungeon-800 px-4 py-2 rounded border border-green-500/30">Número objetivo</span>
                            </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 text-center">
                            <div className="bg-dungeon-900/50 p-4 rounded border-l-4 border-gold-500">
                                <div className="text-3xl font-bold text-gold-400 mb-2">1</div>
                                <div className="text-sm text-dungeon-300">Tira un d20</div>
                            </div>
                            <div className="bg-dungeon-900/50 p-4 rounded border-l-4 border-blue-500">
                                <div className="text-3xl font-bold text-blue-400 mb-2">2</div>
                                <div className="text-sm text-dungeon-300">Suma modificadores</div>
                            </div>
                            <div className="bg-dungeon-900/50 p-4 rounded border-l-4 border-green-500">
                                <div className="text-3xl font-bold text-green-400 mb-2">3</div>
                                <div className="text-sm text-dungeon-300">Compara con CD</div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Tipos de tiradas */}
                <Card className="card border-blue-500/30">
                    <CardHeader className="bg-gradient-to-r from-blue-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Dices className="h-6 w-6 text-blue-400" />
                            Tipos de tiradas
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8 space-y-6">
                        {/* Tabla de tipos */}
                        <div className="overflow-x-auto">
                            <table className="w-full border-collapse">
                                <thead>
                                    <tr className="border-b-2 border-blue-500/30">
                                        <th className="text-left p-3 text-blue-400">Tipo</th>
                                        <th className="text-left p-3 text-blue-400">Cuándo usar</th>
                                        <th className="text-left p-3 text-blue-400">Fórmula</th>
                                    </tr>
                                </thead>
                                <tbody className="text-dungeon-200">
                                    <tr className="border-b border-dungeon-700 hover:bg-dungeon-900/30">
                                        <td className="p-3">
                                            <span className="font-bold text-green-400">Prueba de habilidad</span>
                                        </td>
                                        <td className="p-3 text-sm">Usar una habilidad entrenada</td>
                                        <td className="p-3 font-mono text-sm">1d20 + rangos + mod característica</td>
                                    </tr>
                                    <tr className="border-b border-dungeon-700 hover:bg-dungeon-900/30">
                                        <td className="p-3">
                                            <span className="font-bold text-yellow-400">Prueba de característica</span>
                                        </td>
                                        <td className="p-3 text-sm">Sin habilidad aplicable</td>
                                        <td className="p-3 font-mono text-sm">1d20 + mod característica</td>
                                    </tr>
                                    <tr className="border-b border-dungeon-700 hover:bg-dungeon-900/30">
                                        <td className="p-3">
                                            <span className="font-bold text-red-400">Tirada de ataque</span>
                                        </td>
                                        <td className="p-3 text-sm">Golpear a un enemigo</td>
                                        <td className="p-3 font-mono text-sm">1d20 + BAB + mod + bonos</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        {/* Detalles de pruebas */}
                        <div className="grid md:grid-cols-2 gap-4">
                            <div className="bg-green-900/10 border border-green-500/30 rounded-lg p-4">
                                <h4 className="font-bold text-green-400 mb-2 flex items-center gap-2">
                                    <CheckCircle className="h-4 w-4" />
                                    Pruebas no enfrentadas
                                </h4>
                                <p className="text-sm text-dungeon-300">
                                    El DM establece una CD fija (típicamente 10-30). Ejemplo: escalar un muro (CD 15).
                                </p>
                            </div>
                            <div className="bg-purple-900/10 border border-purple-500/30 rounded-lg p-4">
                                <h4 className="font-bold text-purple-400 mb-2 flex items-center gap-2">
                                    <Swords className="h-4 w-4" />
                                    Pruebas enfrentadas
                                </h4>
                                <p className="text-sm text-dungeon-300">
                                    Tu resultado vs. el resultado del oponente. Ejemplo: esconderse vs. avistar.
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Los dados del juego */}
                <Card className="card border-purple-500/30">
                    <CardHeader className="bg-gradient-to-r from-purple-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Dices className="h-6 w-6 text-purple-400" />
                            Los dados del juego
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                            {[
                                { die: 'd4', desc: 'Dagas, hondas', color: 'yellow' },
                                { die: 'd6', desc: 'Espadas cortas', color: 'green' },
                                { die: 'd8', desc: 'Espadas largas', color: 'blue' },
                                { die: 'd10', desc: 'Bastardas', color: 'purple' },
                                { die: 'd12', desc: 'Hachas grandes', color: 'red' },
                                { die: 'd20', desc: 'Principal del sistema', color: 'gold' },
                                { die: 'd%', desc: 'Tabla porcentajes', color: 'cyan' },
                                { die: 'd100', desc: '2d10 (decenas + unidades)', color: 'pink' },
                            ].map(({ die, desc, color }) => (
                                <div key={die} className={`bg-${color}-900/20 border border-${color}-500/30 rounded-lg p-4 text-center`}>
                                    <div className={`text-2xl font-mono font-bold text-${color}-400 mb-1`}>{die}</div>
                                    <div className="text-xs text-dungeon-400">{desc}</div>
                                </div>
                            ))}
                        </div>

                        <div className="bg-dungeon-900/50 border border-dungeon-700 rounded-lg p-4">
                            <h4 className="font-bold text-gold-400 mb-3">Notación de dados:</h4>
                            <div className="grid md:grid-cols-3 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                    <code className="bg-dungeon-800 px-2 py-1 rounded text-green-400">3d6</code>
                                    <span className="text-dungeon-300">= 3 dados de 6 caras</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <code className="bg-dungeon-800 px-2 py-1 rounded text-blue-400">2d8+5</code>
                                    <span className="text-dungeon-300">= 2 dados de 8 caras + 5</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <code className="bg-dungeon-800 px-2 py-1 rounded text-purple-400">1d20+7</code>
                                    <span className="text-dungeon-300">= 1 dado de 20 caras + 7</span>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Reglas matemáticas */}
                <Card className="card border-dungeon-500/30">
                    <CardHeader className="bg-gradient-to-r from-dungeon-800/50 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Calculator className="h-6 w-6 text-dungeon-200" />
                            Reglas matemáticas
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8 space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <div>
                                <h4 className="font-bold text-dungeon-100 mb-2 flex items-center gap-2">
                                    <Divide className="h-4 w-4 text-dungeon-300" />
                                    Redondeo de fracciones
                                </h4>
                                <p className="text-sm text-dungeon-200 mb-2">
                                    En general, si obtienes una fracción, <strong>redondea siempre hacia abajo</strong>, incluso si es 0.5 o más.
                                </p>
                                <div className="bg-dungeon-900/30 p-3 rounded border-l-2 border-dungeon-500 text-xs text-dungeon-300">
                                    <strong>Excepción:</strong> Ciertas tiradas, como el daño y los puntos de golpe, tienen un mínimo de 1.
                                </div>
                            </div>
                            <div>
                                <h4 className="font-bold text-dungeon-100 mb-2 flex items-center gap-2">
                                    <XCircle className="h-4 w-4 text-dungeon-300" />
                                    Multiplicadores
                                </h4>
                                <p className="text-sm text-dungeon-200 mb-2">
                                    Cuando aplicas dos o más multiplicadores a una tirada (ej. un crítico x2 y una espada x2), se suman los multiplicadores, no se multiplican.
                                </p>
                                <div className="bg-dungeon-900/30 p-3 rounded border-l-2 border-dungeon-500 text-xs font-mono text-dungeon-300">
                                    x2 + x2 = x3<br />
                                    x2 + x3 = x4
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Cuándo tirar los dados */}
                <Card className="card border-cyan-500/30">
                    <CardHeader className="bg-gradient-to-r from-cyan-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Zap className="h-6 w-6 text-cyan-400" />
                            Cuándo tirar los dados
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                        <div className="grid md:grid-cols-2 gap-6">
                            <div>
                                <div className="flex items-center gap-2 mb-4">
                                    <CheckCircle className="h-5 w-5 text-green-400" />
                                    <h4 className="font-bold text-green-400">TIRA dados cuando:</h4>
                                </div>
                                <ul className="space-y-2 text-dungeon-200">
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-400 mt-1">•</span>
                                        <span>El resultado es incierto</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-400 mt-1">•</span>
                                        <span>El fracaso tiene consecuencias</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-400 mt-1">•</span>
                                        <span>Estás en combate</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-green-400 mt-1">•</span>
                                        <span>Hay presión de tiempo</span>
                                    </li>
                                </ul>
                            </div>
                            <div>
                                <div className="flex items-center gap-2 mb-4">
                                    <XCircle className="h-5 w-5 text-red-400" />
                                    <h4 className="font-bold text-red-400">NO tires dados cuando:</h4>
                                </div>
                                <ul className="space-y-2 text-dungeon-200">
                                    <li className="flex items-start gap-2">
                                        <span className="text-red-400 mt-1">•</span>
                                        <span>El éxito es automático</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-red-400 mt-1">•</span>
                                        <span>El fracaso es imposible</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-red-400 mt-1">•</span>
                                        <span>No hay consecuencias</span>
                                    </li>
                                    <li className="flex items-start gap-2">
                                        <span className="text-red-400 mt-1">•</span>
                                        <span>Solo requiere tiempo</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* El asalto de combate */}
                <Card className="card border-red-500/30">
                    <CardHeader className="bg-gradient-to-r from-red-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Swords className="h-6 w-6 text-red-400" />
                            El asalto de combate
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8 space-y-6">
                        <div className="bg-red-900/10 border-l-4 border-red-500 p-4 rounded">
                            <p className="text-lg">
                                Cada <span className="text-red-400 font-bold">asalto</span> representa <span className="text-gold-400 font-bold">~6 segundos</span> de acción.
                            </p>
                        </div>

                        {/* Tabla de Acciones */}
                        <div>
                            <h4 className="font-bold text-gold-400 mb-3">Acciones disponibles en tu turno:</h4>
                            <div className="overflow-x-auto">
                                <table className="w-full border-collapse">
                                    <thead>
                                        <tr className="border-b-2 border-red-500/30">
                                            <th className="text-left p-3 text-red-400">Opción</th>
                                            <th className="text-left p-3 text-red-400">Qué puedes hacer</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-dungeon-200">
                                        <tr className="border-b border-dungeon-700">
                                            <td className="p-3 text-green-400">1</td>
                                            <td className="p-3">Acción estándar + acción de movimiento</td>
                                        </tr>
                                        <tr className="border-b border-dungeon-700">
                                            <td className="p-3 text-blue-400">2</td>
                                            <td className="p-3">Acción de movimiento + acción estándar</td>
                                        </tr>
                                        <tr className="border-b border-dungeon-700">
                                            <td className="p-3 text-yellow-400">3</td>
                                            <td className="p-3">Dos acciones de movimiento</td>
                                        </tr>
                                        <tr>
                                            <td className="p-3 text-purple-400">4</td>
                                            <td className="p-3">Una acción de asalto completo</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p className="text-sm text-dungeon-400 mt-2">
                                Además: siempre puedes realizar acciones rápidas e inmediatas si están disponibles.
                            </p>
                        </div>

                        {/* Iniciativa */}
                        <div className="bg-dungeon-900/50 border border-blue-500/30 rounded-lg p-4">
                            <h4 className="font-bold text-blue-400 mb-2">Iniciativa:</h4>
                            <p className="font-mono text-center text-lg mb-2">
                                <span className="text-gold-400">1d20</span> + <span className="text-green-400">mod Destreza</span> + <span className="text-blue-400">otros bonos</span>
                            </p>
                            <p className="text-sm text-dungeon-300 text-center">
                                Actúas en orden de mayor a menor. El orden se mantiene todo el combate.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                {/* Críticos y PG */}
                <div className="grid md:grid-cols-2 gap-6">
                    <Card className="card border-yellow-500/30">
                        <CardHeader className="bg-gradient-to-r from-yellow-900/20 to-transparent">
                            <CardTitle className="flex items-center gap-3 text-xl">
                                <Zap className="h-5 w-5 text-yellow-400" />
                                Impactos críticos
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                            <div className="space-y-3">
                                <div className="flex items-start gap-3">
                                    <div className="bg-yellow-500/20 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                                        <span className="text-yellow-400 font-bold">1</span>
                                    </div>
                                    <div>
                                        <div className="font-bold text-yellow-400">Amenaza (20 natural)</div>
                                        <div className="text-sm text-dungeon-300">Potencial impacto crítico</div>
                                    </div>
                                </div>
                                <div className="flex items-start gap-3">
                                    <div className="bg-orange-500/20 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                                        <span className="text-orange-400 font-bold">2</span>
                                    </div>
                                    <div>
                                        <div className="font-bold text-orange-400">Confirmar</div>
                                        <div className="text-sm text-dungeon-300">Tira ataque de nuevo</div>
                                    </div>
                                </div>
                                <div className="flex items-start gap-3">
                                    <div className="bg-red-500/20 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                                        <span className="text-red-400 font-bold">3</span>
                                    </div>
                                    <div>
                                        <div className="font-bold text-red-400">Daño x2 o x3</div>
                                        <div className="text-sm text-dungeon-300">Según el arma</div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="card border-green-500/30">
                        <CardHeader className="bg-gradient-to-r from-green-900/20 to-transparent">
                            <CardTitle className="flex items-center gap-3 text-xl">
                                <Heart className="h-5 w-5 text-green-400" />
                                Puntos de golpe
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                            <div className="space-y-2">
                                <div className="flex justify-between items-center p-2 bg-green-900/20 rounded">
                                    <span className="text-green-400">Positivo</span>
                                    <span className="text-sm text-dungeon-300">Consciente y luchando</span>
                                </div>
                                <div className="flex justify-between items-center p-2 bg-yellow-900/20 rounded">
                                    <span className="text-yellow-400">0 pg</span>
                                    <span className="text-sm text-dungeon-300">Inconsciente</span>
                                </div>
                                <div className="flex justify-between items-center p-2 bg-orange-900/20 rounded">
                                    <span className="text-orange-400">-1 a -9 pg</span>
                                    <span className="text-sm text-dungeon-300">Muriendo</span>
                                </div>
                                <div className="flex justify-between items-center p-2 bg-red-900/20 rounded">
                                    <span className="text-red-400">-10 pg</span>
                                    <span className="text-sm text-dungeon-300">Muerto</span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Modificadores comunes */}
                <Card className="card border-gold-500/30">
                    <CardHeader className="bg-gradient-to-r from-gold-900/20 to-transparent">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                            <Shield className="h-6 w-6 text-gold-400" />
                            Modificadores comunes
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div className="bg-red-900/10 border border-red-500/30 rounded-lg p-4">
                                <div className="font-bold text-red-400 mb-1">Características</div>
                                <div className="text-sm text-dungeon-400">Fue, Des, Con, Int, Sab, Car</div>
                                <div className="text-xs text-dungeon-500 mt-1 font-mono">(Puntuación - 10) / 2</div>
                            </div>
                            {[
                                { name: 'Rangos de habilidad', desc: 'Entrenamiento específico', color: 'green' },
                                { name: 'Dotes', desc: 'Talentos especiales', color: 'blue' },
                                { name: 'Objetos mágicos', desc: 'Bonificadores de equipo', color: 'purple' },
                                { name: 'Conjuros', desc: 'Efectos temporales', color: 'cyan' },
                                { name: 'Circunstancias', desc: 'Situacionales', color: 'yellow' },
                            ].map(({ name, desc, color }) => (
                                <div key={name} className={`bg-${color}-900/10 border border-${color}-500/30 rounded-lg p-4`}>
                                    <div className={`font-bold text-${color}-400 mb-1`}>{name}</div>
                                    <div className="text-sm text-dungeon-400">{desc}</div>
                                </div>
                            ))}
                        </div>
                        <div className="mt-6 bg-gold-900/20 border-2 border-gold-500/50 rounded-lg p-4 text-center">
                            <p className="text-gold-300 font-bold text-lg">
                                ⚠️ Regla importante: bonificadores del mismo tipo NO se acumulan
                            </p>
                            <p className="text-sm text-dungeon-300 mt-2">
                                Solo aplicas el bonificador mayor de cada tipo.
                            </p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Back Button */}
            <div className="flex gap-4 mt-12">
                <Link href="/reglas">
                    <Button variant="outline">
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Volver a reglas
                    </Button>
                </Link>
                <Link href="/">
                    <Button variant="ghost">Inicio</Button>
                </Link>
            </div>
        </div>
    );
}
