"use client";

import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import {
    Sword,
    Shield,
    Activity,
    Footprints,
    Zap,
    Skull,
    Clock,
    AlertTriangle,
    Flame,
    Target
} from 'lucide-react';
import { CombatBasics } from './CombatBasics';
import { Initiative } from './Initiative';
import { Actions } from './Actions';
import { Injury } from './Injury';
import { Movement } from './Movement';
import { Modifiers } from './Modifiers';
import { SpecialAttacks } from './SpecialAttacks';
import { SpecialAbilities } from './SpecialAbilities';
import { SpecialInitiative } from './SpecialInitiative';

type Tab = 'fundamentos' | 'iniciativa' | 'acciones' | 'heridas' | 'movimiento' | 'modificadores' | 'ataques-especiales' | 'habilidades' | 'iniciativa-especial';

export default function CombatPage() {
    const [activeTab, setActiveTab] = useState<Tab>('fundamentos');
    const contentRef = useRef<HTMLDivElement>(null);

    const handleTabChange = (tabId: Tab) => {
        setActiveTab(tabId);
        // Small timeout to ensure state update and render cycle have started
        setTimeout(() => {
            if (contentRef.current) {
                const y = contentRef.current.getBoundingClientRect().top + window.scrollY - 180; // Adjust offset for header + tabs
                window.scrollTo({ top: y, behavior: 'smooth' });
            }
        }, 0);
    };

    const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
        { id: 'fundamentos', label: 'Fundamentos', icon: Sword },
        { id: 'iniciativa', label: 'Iniciativa', icon: Clock },
        { id: 'acciones', label: 'Acciones', icon: Activity },
        { id: 'heridas', label: 'Heridas', icon: Skull },
        { id: 'movimiento', label: 'Movimiento', icon: Footprints },
        { id: 'modificadores', label: 'Modificadores', icon: Shield },
        { id: 'ataques-especiales', label: 'Ataques Esp.', icon: Zap },
        { id: 'habilidades', label: 'Habilidades', icon: Flame },
        { id: 'iniciativa-especial', label: 'Inic. Especial', icon: AlertTriangle },
    ];

    return (
        <div className="container mx-auto py-8 space-y-8">
            <div className="flex flex-col space-y-4">
                <h1 className="text-4xl font-bold text-dungeon-100 text-center font-serif">
                    Combate
                </h1>
                <p className="text-xl text-dungeon-300 text-center max-w-3xl mx-auto">
                    El choque de acero, el rugido de la magia y el caos de la batalla. Aquí encontrarás todo lo necesario para resolver conflictos armados.
                </p>
            </div>

            {/* Navigation Tabs */}
            <div className="flex flex-wrap justify-center gap-2 sticky top-20 z-40 bg-dungeon-950/90 p-4 rounded-xl backdrop-blur-sm border border-dungeon-800 shadow-xl">
                {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                        <Button
                            key={tab.id}
                            variant={activeTab === tab.id ? "default" : "outline"}
                            onClick={() => handleTabChange(tab.id)}
                            className={`flex items-center gap-2 transition-all duration-300 ${activeTab === tab.id
                                ? 'bg-red-900/80 hover:bg-red-800 text-red-100 border-red-700 shadow-lg shadow-red-900/20 scale-105'
                                : 'text-dungeon-300 border-dungeon-700 hover:bg-dungeon-800 hover:text-dungeon-100'
                                }`}
                        >
                            <Icon className="h-4 w-4" />
                            <span className="hidden md:inline">{tab.label}</span>
                        </Button>
                    );
                })}
            </div>

            {/* Content Area */}
            <div ref={contentRef} className="min-h-[500px] animate-in fade-in slide-in-from-bottom-4 duration-500 scroll-mt-40">
                {activeTab === 'fundamentos' && <CombatBasics />}
                {activeTab === 'iniciativa' && <Initiative />}
                {activeTab === 'acciones' && <Actions />}
                {activeTab === 'heridas' && <Injury />}
                {activeTab === 'movimiento' && <Movement />}
                {activeTab === 'modificadores' && <Modifiers />}
                {activeTab === 'ataques-especiales' && <SpecialAttacks />}
                {activeTab === 'habilidades' && <SpecialAbilities />}
                {activeTab === 'iniciativa-especial' && <SpecialInitiative />}
            </div>
        </div>
    );
}
