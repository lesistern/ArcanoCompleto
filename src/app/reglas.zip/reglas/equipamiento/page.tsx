"use client";

import React, { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { ArrowLeft, Backpack, Coins, Sword, Shield, Package, Scale, Info, Clock, Hammer, CircleDollarSign, AlertTriangle, HelpCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';

export default function EquipamientoPage() {
    const [activeTab, setActiveTab] = useState('general');

    return (
        <div className="container mx-auto px-4 py-16 max-w-6xl">
            {/* Back Button */}
            <div className="mb-8">
                <Link href="/reglas">
                    <Button variant="outline">
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Volver a reglas
                    </Button>
                </Link>
            </div>

            {/* Header */}
            <div className="border-l-4 border-amber-500 pl-6 mb-12">
                <div className="flex items-center gap-3 mb-3">
                    <Backpack className="h-8 w-8 text-amber-500" />
                    <h1 className="font-heading text-4xl md:text-5xl font-bold text-dungeon-100">
                        Equipamiento
                    </h1>
                </div>
                <p className="text-lg text-dungeon-300">
                    Todo lo que necesitas saber sobre riqueza, armas y armaduras para sobrevivir a tus aventuras.
                </p>
            </div>

            {/* Tabs Navigation */}
            <div className="flex flex-wrap gap-2 mb-8 border-b border-dungeon-700 pb-1">
                <button
                    onClick={() => setActiveTab('general')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-t-lg transition-colors ${activeTab === 'general'
                        ? 'bg-amber-500 text-dungeon-900 font-bold'
                        : 'bg-dungeon-800 text-dungeon-300 hover:bg-dungeon-700'
                        }`}
                >
                    <Coins className="h-4 w-4" />
                    Economía y general
                </button>
                <button
                    onClick={() => setActiveTab('armas')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-t-lg transition-colors ${activeTab === 'armas'
                        ? 'bg-red-500 text-dungeon-100 font-bold'
                        : 'bg-dungeon-800 text-dungeon-300 hover:bg-dungeon-700'
                        }`}
                >
                    <Sword className="h-4 w-4" />
                    Armas
                </button>
                <button
                    onClick={() => setActiveTab('armaduras')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-t-lg transition-colors ${activeTab === 'armaduras'
                        ? 'bg-blue-500 text-dungeon-100 font-bold'
                        : 'bg-dungeon-800 text-dungeon-300 hover:bg-dungeon-700'
                        }`}
                >
                    <Shield className="h-4 w-4" />
                    Armaduras
                </button>
            </div>

            {/* Content */}
            <div className="space-y-8 text-dungeon-200">
                {activeTab === 'general' && (
                    <div className="grid gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {/* Equipamiento Inicial */}
                        <Card className="card border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-amber-400">
                                    <Package className="h-5 w-5" />
                                    Equipando a un personaje
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <p>
                                    Un personaje recién creado suele comenzar con lo básico: un arma, una armadura sencilla y una mochila con provisiones. A medida que completes aventuras, encontrarás tesoros que te permitirán comprar mejor equipo.
                                </p>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div className="bg-dungeon-900/50 p-4 rounded border border-dungeon-700">
                                        <h4 className="font-bold text-amber-400 mb-2">Paquetes iniciales</h4>
                                        <p className="text-sm mb-2">
                                            Es la opción más rápida. Cada clase tiene un "kit" predefinido que incluye todo lo necesario para empezar a jugar (armas, armadura, mochila, saco de dormir, antorchas, etc.).
                                        </p>
                                        <p className="text-xs text-dungeon-400 italic">
                                            Puedes personalizarlo intercambiando objetos por otros de igual o menor valor.
                                        </p>
                                    </div>
                                    <div className="bg-dungeon-900/50 p-4 rounded border border-dungeon-700">
                                        <h4 className="font-bold text-amber-400 mb-2">Equipo a la carta</h4>
                                        <p className="text-sm mb-2">
                                            Para jugadores que quieren control total. Tiras dados para determinar tu oro inicial y compras cada objeto por separado.
                                        </p>
                                        <p className="text-xs text-dungeon-400 italic">
                                            Requiere más tiempo pero permite una personalización exacta.
                                        </p>
                                    </div>
                                </div>

                                <div>
                                    <h4 className="font-bold text-amber-300 mb-3 text-sm uppercase tracking-wider">Oro inicial aleatorio</h4>
                                    <div className="overflow-x-auto bg-dungeon-900/30 rounded-lg border border-dungeon-700">
                                        <table className="w-full text-sm text-left">
                                            <thead className="text-dungeon-400 border-b border-dungeon-700 bg-dungeon-800/50">
                                                <tr>
                                                    <th className="py-2 px-4">Clase</th>
                                                    <th className="py-2 px-4">Cantidad</th>
                                                    <th className="py-2 px-4">Clase</th>
                                                    <th className="py-2 px-4">Cantidad</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-dungeon-800">
                                                <tr><td className="py-2 px-4">Bárbaro</td><td className="py-2 px-4">4d4 × 10 (100 po)</td><td className="py-2 px-4">Monje</td><td className="py-2 px-4">5d4 (12 po)</td></tr>
                                                <tr><td className="py-2 px-4">Bardo</td><td className="py-2 px-4">4d4 × 10 (100 po)</td><td className="py-2 px-4">Paladín</td><td className="py-2 px-4">6d4 × 10 (150 po)</td></tr>
                                                <tr><td className="py-2 px-4">Clérigo</td><td className="py-2 px-4">5d4 × 10 (125 po)</td><td className="py-2 px-4">Explorador</td><td className="py-2 px-4">6d4 × 10 (150 po)</td></tr>
                                                <tr><td className="py-2 px-4">Druida</td><td className="py-2 px-4">2d4 × 10 (50 po)</td><td className="py-2 px-4">Pícaro</td><td className="py-2 px-4">5d4 × 10 (125 po)</td></tr>
                                                <tr><td className="py-2 px-4">Guerrero</td><td className="py-2 px-4">6d4 × 10 (150 po)</td><td className="py-2 px-4">Hechicero/Mago</td><td className="py-2 px-4">3d4 × 10 (75 po)</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="flex items-start gap-3 bg-amber-900/10 p-4 rounded border border-amber-500/20">
                                    <Info className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
                                    <div className="text-sm">
                                        <strong className="text-amber-400 block mb-1">Disponibilidad de objetos</strong>
                                        No todos los objetos están disponibles en todas partes. En una aldea pequeña será difícil encontrar una armadura completa o una espada mágica. Para comprar objetos caros (más de 3,000 po), generalmente necesitarás viajar a una gran ciudad.
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Economía */}
                        <Card className="card border-amber-500/30">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-amber-400">
                                    <CircleDollarSign className="h-5 w-5" />
                                    Economía
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <p>
                                    La moneda estándar de D&D es la <strong>Pieza de Oro (po)</strong>. Aunque los plebeyos suelen usar plata o cobre para sus transacciones diarias, los aventureros manejan sumas mayores.
                                </p>

                                <div>
                                    <h4 className="font-bold text-amber-300 mb-3 text-sm uppercase tracking-wider">Tabla 7-2: Monedas</h4>
                                    <div className="overflow-x-auto bg-dungeon-900/30 rounded-lg border border-dungeon-700">
                                        <table className="w-full text-sm text-center">
                                            <thead className="text-dungeon-400 border-b border-dungeon-700 bg-dungeon-800/50">
                                                <tr>
                                                    <th className="py-2 px-4 text-left">Moneda</th>
                                                    <th className="py-2 px-4">pc</th>
                                                    <th className="py-2 px-4">pp</th>
                                                    <th className="py-2 px-4">po</th>
                                                    <th className="py-2 px-4">ppt</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-dungeon-800 text-dungeon-200">
                                                <tr><td className="py-2 px-4 text-left font-medium text-orange-400">Pieza de cobre (pc)</td><td>1</td><td>1/10</td><td>1/100</td><td>1/1,000</td></tr>
                                                <tr><td className="py-2 px-4 text-left font-medium text-dungeon-200">Pieza de plata (pp)</td><td>10</td><td>1</td><td>1/10</td><td>1/100</td></tr>
                                                <tr><td className="py-2 px-4 text-left font-medium text-amber-400">Pieza de oro (po)</td><td>100</td><td>10</td><td>1</td><td>1/10</td></tr>
                                                <tr><td className="py-2 px-4 text-left font-medium text-slate-300">Pieza de platino (ppt)</td><td>1,000</td><td>100</td><td>10</td><td>1</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-bold text-amber-300 mb-2">Comercio y trueque</h4>
                                        <p className="text-sm mb-3">
                                            Para transacciones muy grandes, llevar miles de monedas es impráctico (pesan mucho). Los comerciantes y aventureros suelen usar <strong>bienes comerciales</strong> (gemas, joyas, arte, lingotes) que mantienen su valor completo y son fáciles de transportar.
                                        </p>
                                        <div className="bg-dungeon-900/30 rounded border border-dungeon-700 p-3 text-xs">
                                            <ul className="space-y-1">
                                                <li className="flex justify-between"><span>1 lb. de trigo</span> <span className="text-dungeon-400">1 pc</span></li>
                                                <li className="flex justify-between"><span>1 lb. de hierro</span> <span className="text-dungeon-400">1 pp</span></li>
                                                <li className="flex justify-between"><span>1 cabra</span> <span className="text-dungeon-400">1 po</span></li>
                                                <li className="flex justify-between"><span>1 lb. de oro</span> <span className="text-dungeon-400">50 po</span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-amber-300 mb-2">Venta de botín</h4>
                                        <p className="text-sm mb-2">
                                            Cuando encuentras armas o armaduras en un dungeon y quieres venderlas en la ciudad, los comerciantes no te pagarán el precio completo.
                                        </p>
                                        <ul className="space-y-2 text-sm bg-dungeon-900/30 p-3 rounded border border-dungeon-700">
                                            <li className="flex items-start gap-2">
                                                <span className="text-amber-500 font-bold">50%</span>
                                                <span>Es lo que obtienes al vender equipo usado (armas, armaduras, etc.).</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-amber-500 font-bold">100%</span>
                                                <span>Las gemas, obras de arte y bienes comerciales se cambian por su valor total.</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {activeTab === 'armas' && (
                    <div className="grid gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {/* Clasificación */}
                        <Card className="card border-red-500/30">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-red-400">
                                    <Sword className="h-5 w-5" />
                                    Clasificación de armas
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <p>
                                    No todas las armas son iguales. Algunas son herramientas simples que cualquiera puede usar, mientras que otras requieren años de entrenamiento especializado.
                                </p>
                                <div className="grid md:grid-cols-3 gap-4 text-sm">
                                    <div className="bg-dungeon-900/50 p-4 rounded border-l-2 border-green-500">
                                        <strong className="text-green-400 block mb-2 text-base">Sencillas</strong>
                                        <p>Armas de uso intuitivo como garrotes, dagas o ballestas. Casi todas las clases (excepto magos, monjes y druidas) saben usarlas todas.</p>
                                    </div>
                                    <div className="bg-dungeon-900/50 p-4 rounded border-l-2 border-red-500">
                                        <strong className="text-red-400 block mb-2 text-base">Marciales</strong>
                                        <p>Armas diseñadas específicamente para la guerra, como espadas largas, hachas de batalla y arcos. Requieren entrenamiento militar (Guerreros, Paladines, Bárbaros, etc.).</p>
                                    </div>
                                    <div className="bg-dungeon-900/50 p-4 rounded border-l-2 border-purple-500">
                                        <strong className="text-purple-400 block mb-2 text-base">Exóticas</strong>
                                        <p>Armas extrañas o muy complejas, como el nunchaku o la cadena armada. Necesitas gastar una dote ("Competencia con arma exótica") para usarlas sin penalizador.</p>
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-8">
                                    <div>
                                        <h4 className="font-bold text-red-300 mb-3 border-b border-red-500/20 pb-1">Categorías de uso</h4>
                                        <ul className="space-y-3 text-sm">
                                            <li>
                                                <strong className="text-dungeon-100 block">Cuerpo a cuerpo vs A distancia</strong>
                                                Las armas cuerpo a cuerpo se usan adyacentes al enemigo. Las armas a distancia atacan desde lejos.
                                            </li>
                                            <li>
                                                <strong className="text-dungeon-100 block">Alcance (Reach)</strong>
                                                Armas largas (como lanzas) que permiten atacar a enemigos a 10 pies de distancia, golpeándolos antes de que se acerquen a ti.
                                            </li>
                                            <li>
                                                <strong className="text-dungeon-100 block">Arrojadizas vs Proyectil</strong>
                                                Las arrojadizas (hachas de mano, jabalinas) suman tu Fuerza al daño. Las de proyectil (arcos, ballestas) generalmente no, pero tienen mucho mayor alcance.
                                            </li>
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-red-300 mb-3 border-b border-red-500/20 pb-1">Esfuerzo y tamaño</h4>
                                        <ul className="space-y-3 text-sm">
                                            <li>
                                                <strong className="text-dungeon-100 block">Ligeras</strong>
                                                Se pueden usar en una sola mano y son ideales para combatir con dos armas (usándola en la mano torpe).
                                            </li>
                                            <li>
                                                <strong className="text-dungeon-100 block">A dos manos</strong>
                                                Requieren ambas manos para usarse, por lo que no puedes llevar escudo. A cambio, haces mucho más daño (x1.5 tu bonificador de Fuerza).
                                            </li>
                                            <li className="bg-red-900/10 p-2 rounded border border-red-500/20 text-xs">
                                                <strong>Nota sobre tamaño:</strong> Las armas están hechas para un tamaño específico (Pequeño, Mediano). Si un humano intenta usar una espada de ogro (Grande), tendrá un penalizador de -2 al ataque por la diferencia de tamaño.
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3 bg-red-900/10 p-3 rounded border border-red-500/20 text-sm">
                                    <AlertTriangle className="h-5 w-5 text-red-500 shrink-0" />
                                    <span>
                                        <strong>Armas improvisadas:</strong> A veces tienes que pelear con lo que tienes a mano (una silla, una botella rota). Como no están equilibradas para el combate, tienes un penalizador de <strong>-4 al ataque</strong>.
                                    </span>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Estadísticas */}
                        <Card className="card border-red-500/30">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-red-400">
                                    <Info className="h-5 w-5" />
                                    Entendiendo las estadísticas
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                                    <div className="space-y-4">
                                        <div>
                                            <strong className="text-red-400 block mb-1">Crítico (Ej: 19-20/x2)</strong>
                                            <p className="text-dungeon-300">
                                                El primer número es el <strong>Rango de Amenaza</strong>: qué necesitas sacar en el dado d20 para amenazar crítico (normalmente solo 20, pero algunas armas lo hacen con 19 o incluso 18).
                                                <br />
                                                El segundo es el <strong>Multiplicador</strong>: por cuánto multiplicas el daño si confirmas el crítico (x2, x3, x4).
                                            </p>
                                        </div>
                                        <div>
                                            <strong className="text-red-400 block mb-1">Incremento de distancia</strong>
                                            <p className="text-dungeon-300">
                                                Puedes disparar más lejos que este número, pero es más difícil apuntar. Tienes un penalizador de -2 al ataque por cada "incremento" extra de distancia.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="space-y-4">
                                        <div>
                                            <strong className="text-red-400 block mb-1">Tipo de daño</strong>
                                            <p className="text-dungeon-300">
                                                Importante contra ciertos monstruos (ej. esqueletos resisten todo menos golpes contundentes).
                                            </p>
                                            <ul className="list-disc list-inside pl-2 text-xs text-dungeon-400 mt-1">
                                                <li><strong>Contundente:</strong> Martillos, mazas.</li>
                                                <li><strong>Perforante:</strong> Lanzas, flechas, dagas.</li>
                                                <li><strong>Cortante:</strong> Espadas, hachas.</li>
                                            </ul>
                                        </div>
                                        <div className="bg-amber-900/10 p-2 rounded border border-amber-500/20">
                                            <strong className="text-amber-400 block mb-1">Gran Calidad (Masterwork)</strong>
                                            <p className="text-dungeon-300 text-xs">
                                                Armas forjadas por maestros. Son más caras (+300 po) pero están tan bien equilibradas que te dan un <strong>+1 al ataque</strong> (no al daño).
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <h4 className="font-bold text-red-300 mb-2 text-sm">Daño según tamaño (Tabla 7-4)</h4>
                                    <p className="text-xs text-dungeon-400 mb-2">
                                        El daño listado en las tablas suele ser para tamaño Mediano. Si eres Pequeño (Gnomo, Mediano) o Grande, el daño cambia:
                                    </p>
                                    <div className="overflow-x-auto bg-dungeon-900/30 rounded border border-dungeon-700">
                                        <table className="w-full text-sm text-center">
                                            <thead className="text-dungeon-400 bg-dungeon-800/50 text-xs">
                                                <tr>
                                                    <th className="py-1">Mediana</th>
                                                    <th className="py-1">Diminuta</th>
                                                    <th className="py-1">Grande</th>
                                                    <th className="py-1 border-l border-dungeon-700">Mediana</th>
                                                    <th className="py-1">Diminuta</th>
                                                    <th className="py-1">Grande</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-dungeon-800 text-dungeon-300">
                                                <tr>
                                                    <td className="py-1 font-bold text-dungeon-100">1d4</td><td>1d2</td><td>1d6</td>
                                                    <td className="py-1 border-l border-dungeon-700 font-bold text-dungeon-100">1d8</td><td>1d4</td><td>2d6</td>
                                                </tr>
                                                <tr>
                                                    <td className="py-1 font-bold text-dungeon-100">1d6</td><td>1d3</td><td>1d8</td>
                                                    <td className="py-1 border-l border-dungeon-700 font-bold text-dungeon-100">2d6</td><td>1d8</td><td>3d6</td>
                                                </tr>
                                                <tr>
                                                    <td className="py-1 font-bold text-dungeon-100">1d10</td><td>1d6</td><td>2d8</td>
                                                    <td className="py-1 border-l border-dungeon-700 font-bold text-dungeon-100">1d12</td><td>1d8</td><td>3d6</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}
            </div>
        </div>
    );
}
